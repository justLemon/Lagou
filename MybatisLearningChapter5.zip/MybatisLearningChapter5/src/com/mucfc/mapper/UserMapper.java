package com.mucfc.mapper;

import com.mucfc.model.User;
/**
 * Mapperӳ����
 * @author linbingwen
 * @time 2015.5.15
 */
public interface UserMapper {
	public User selectUserById(int userId);

}
