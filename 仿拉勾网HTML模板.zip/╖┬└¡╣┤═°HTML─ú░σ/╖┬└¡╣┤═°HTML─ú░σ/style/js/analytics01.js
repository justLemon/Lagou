//baidu
var _bdhmProtocol = (("https:" == document.location.protocol) ? " https://" : " http://");
document.write(unescape("%3Cscript src='" + _bdhmProtocol + "hm.baidu.com/h.js%3F4233e74dff0ae5bd0a3d81c6ccf756e6' type='text/javascript'%3E%3C/script%3E"));
//google analytics
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

 /* ga('create', 'UA-41268416-1', 'lagou.com');
  ga('send', 'pageview');*/
ga('create', 'UA-41268416-1', 'lagou.com', {
		  'allowLinker': true
		});
		ga('require', 'linker');
		ga('linker:autoLink', ['lagoujobs.com'],true );
		ga('send', 'pageview');